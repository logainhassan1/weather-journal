/* Global Variables */

const btn = document.querySelector('#generate')




// Create a new date instance dynamically with JS

let d = new Date();
let newDate = d.getMonth()+'.'+ d.getDate()+'.'+ d.getFullYear();





// Personal API Key for OpenWeatherMap API


let APIKey="&appid=06c960e76d49d98e165fd325c8002420&unites=metric";




// when the btn is clicked

const click=()=>{
        const zipcode =document.querySelector('#zip').value;
        const feelings=document.querySelector('#feelings').value;
        let url=`http://api.openweathermap.org/data/2.5/weather?zip=${zipcode}`;
        let fetchdata=resivedata(url);
        fetchdata.then((data)=>{
            let fdata={
                mtemp: data.main.temp,
                mfeeling:feelings,
                date:newDate
            }
        senddata("/add",fdata);
        }).then(()=>retrieveData())
    };






/* Function to GET Web API Data*/

let resivedata= async function(url) {
    const link= url+APIKey;
    const res =await fetch(link);
    try{
    const data =await res.json();
    return data;
}catch (error)
{console.log(error);}}





// /*send data to server */

let senddata = async function(addroute,fdata){

let res =await fetch(addroute,
    { method: 'POST',
     credentials: 'same-origin', 
    headers: {
        'Content-Type': 'application/json',
    },
    body: JSON.stringify(fdata)
});
try {let data1=await res.json();
    console.log(data1);
    
} catch (error) {
    console.log("error",error);}
    
}



const retrieveData = async () =>{
    const request = await fetch('/all');
    try {
    // Transform into JSON
    const allData = await request.json()
    console.log(allData)
    // Write updated data to DOM elements
    document.getElementById('temp').innerHTML = Math.round(allData.temp)+ 'degrees';
    document.getElementById('content').innerHTML = allData.feel;
    document.getElementById("date").innerHTML =allData.date;
    }
    catch(error) {
      console.log("error", error);
      // appropriately handle the error
    }
   }



btn.addEventListener('click', click);