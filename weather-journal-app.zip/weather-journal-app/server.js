// Setup empty JS object to act as endpoint for all routes
let projectData = {};

// Express to run server and routes
const express=require('express');

// Start up an instance of app
const app=express();

/* Dependencies */
let bodyParser = require('body-parser')

/* Middleware*/
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());


// Cors for cross origin allowance
const cors = require('cors');
app.use(cors());


// Initialize the main project folder
app.use(express.static('website'));

/* Spin up the server*/
const port=8000;
const server =app.listen(port, listening);
function listening(){
  console.log(`server running at ${port}`);
};




// Callback to debug




// // Post 




function postdata(req, res) {
   projectData=req.body;
  res.send(projectData);
  console.log(projectData)
}
app.post('/add', postdata);



//get


const  getdata=(req, res)=>{
  res.send(projectData)}

app.get('/all', getdata);

